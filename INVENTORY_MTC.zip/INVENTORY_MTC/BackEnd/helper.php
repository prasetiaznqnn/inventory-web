<?php 

define("BASE_URL", "https://localhost:inven-elastomix/");


?>